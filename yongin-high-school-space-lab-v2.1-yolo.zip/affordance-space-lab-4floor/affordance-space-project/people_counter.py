"""YOLOv8n people counter integrated with the school space app.
Standalone: python people_counter.py --camera 1 --confidence 0.5
The web app uses --managed and receives only count/timestamp events.
Press q / Esc in the OpenCV window, or Stop in the web app, to stop.
"""
from __future__ import annotations
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent
PERSON_CLASS_ID = 0
CAMERA_INDEX = 1
CONFIDENCE_THRESHOLD = 0.5
MODEL_NAME = "yolov8n.pt"
EVENT_PREFIX = "@@PEOPLE_COUNTER@@"

def emit(event: str, **values):
    print(EVENT_PREFIX + json.dumps({"event": event, **values}, ensure_ascii=True), flush=True)

def count_people(boxes):
    return len(boxes) if boxes is not None else 0

def sample_event(count, observed):
    return {"count": count, "observedAt": observed.isoformat(),
            "localDate": observed.strftime("%Y-%m-%d"), "localTime": observed.strftime("%H:%M")}

def parse_args(argv=None):
    p = argparse.ArgumentParser(description="YOLOv8n webcam people counter")
    p.add_argument("--camera", type=int, default=CAMERA_INDEX, help="Camera index; 0 internal / 1 external often")
    p.add_argument("--confidence", type=float, default=CONFIDENCE_THRESHOLD)
    p.add_argument("--managed", action="store_true", help="Node server managed mode")
    p.add_argument("--check", action="store_true", help="Check dependencies without camera/model")
    p.add_argument("--self-test", action="store_true", help="Infer on an empty frame; never open a camera")
    args = p.parse_args(argv)
    if not 0 <= args.camera <= 20:
        p.error("--camera must be an integer from 0 to 20")
    if not 0.05 <= args.confidence <= 0.95:
        p.error("--confidence must be between 0.05 and 0.95")
    if args.managed and (args.check or args.self_test):
        p.error("Test commands cannot run in managed capture mode")
    return args

def load_dependencies():
    state_dir = ROOT / ".yolo-state"
    state_dir.mkdir(exist_ok=True)
    os.environ.setdefault("YOLO_CONFIG_DIR", str(state_dir))
    os.environ.setdefault("MPLCONFIGDIR", str(state_dir / "matplotlib"))
    os.environ.setdefault("TORCH_HOME", str(state_dir / "torch"))
    os.environ.setdefault("YOLO_VERBOSE", "False")
    import cv2
    from ultralytics import YOLO
    return cv2, YOLO

def read_commands(stop):
    try:
        for line in sys.stdin:
            try:
                if json.loads(line).get("command") == "stop":
                    stop.set()
                    return
            except (ValueError, AttributeError):
                continue
    finally:
        stop.set()

def run(args, cv2, YOLO):
    stop = threading.Event()
    if args.managed:
        threading.Thread(target=read_commands, args=(stop,), daemon=True).start()
    cap = None
    window_open = False
    title = "People Counter - YOLOv8n (Q / Esc to stop)"
    try:
        emit("status", phase="loading", message="YOLOv8n 모델을 불러오고 있습니다. 최초 실행에는 모델 다운로드가 필요할 수 있습니다.")
        model_path = ROOT / "models" / MODEL_NAME
        model_path.parent.mkdir(exist_ok=True)
        model = YOLO(str(model_path))
        if args.self_test:
            import numpy as np
            results = model.predict(np.zeros((320, 320, 3), dtype=np.uint8),
                                    classes=[PERSON_CLASS_ID], conf=args.confidence,
                                    verbose=False, save=False, device="cpu")
            emit("self-test", ok=True, count=count_people(results[0].boxes), cameraOpened=False)
            return 0
        if stop.is_set():
            return 0
        emit("status", phase="opening", message="웹캠을 여는 중입니다.")
        if os.name == "nt":
            cap = cv2.VideoCapture(args.camera, cv2.CAP_DSHOW)
            if not cap.isOpened():
                cap.release()
                cap = cv2.VideoCapture(args.camera)
        else:
            cap = cv2.VideoCapture(args.camera)
        if not cap.isOpened():
            raise RuntimeError("웹캠을 열 수 없습니다. 번호를 0 또는 1로 확인하고 다른 앱의 카메라 사용을 종료하세요.")
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        emit("status", phase="running", message="YOLOv8n 탐지 중. 별도 영상 창에서 q 또는 Esc로 종료할 수 있습니다.")
        last_emit = 0.0
        while not stop.is_set():
            ret, frame = cap.read()
            observed = datetime.now().astimezone()
            if not ret:
                if not stop.is_set():
                    raise RuntimeError("웹캠 프레임을 읽을 수 없습니다. 케이블·카메라 사용 상태를 확인하세요.")
                break
            results = model.predict(frame, classes=[PERSON_CLASS_ID], conf=args.confidence,
                                    verbose=False, save=False)
            if stop.is_set():
                break
            boxes = results[0].boxes
            person_count = count_people(boxes)
            if boxes is not None:
                for box in boxes:
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    confidence = float(box.conf[0])
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(frame, f"{confidence:.2f}", (x1, max(y1 - 5, 0)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
            cv2.putText(frame, f"People: {person_count}", (10, 35),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
            cv2.imshow(title, frame)
            window_open = True
            if time.monotonic() - last_emit >= 0.25:
                emit("count", **sample_event(person_count, observed))
                last_emit = time.monotonic()
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), ord("Q"), 27) or cv2.getWindowProperty(title, cv2.WND_PROP_VISIBLE) < 1:
                break
        return 0
    finally:
        stop.set()
        if cap is not None:
            cap.release()
        if window_open:
            cv2.destroyAllWindows()
        emit("stopped")

def main(argv=None):
    args = parse_args(argv)
    try:
        cv2, YOLO = load_dependencies()
        if args.check:
            emit("check", ok=True, python=sys.version.split()[0], opencv=cv2.__version__)
            return 0
        return run(args, cv2, YOLO)
    except ImportError as error:
        emit("error", message="Python 패키지가 없습니다. SETUP_YOLO.cmd를 실행하세요. " + str(error))
        return 1
    except KeyboardInterrupt:
        emit("stopped")
        return 0
    except Exception as error:
        emit("error", message=str(error))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
