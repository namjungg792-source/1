import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { InputError, normalizeInput, analyze, aggregateObservations, timePattern } from './lib/analysis.mjs';
import { recommend } from './lib/recommendations.mjs';
import { createYoloController } from './lib/yolo-controller.mjs';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.wasm': 'application/wasm', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.png': 'image/png', '.tflite': 'application/octet-stream' };
const json = (res, status, value) => { res.writeHead(status, { 'Content-Type': mime['.json'], 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(value)); };
async function readJson(file, fallback) {
  try { return JSON.parse(await fs.readFile(file, 'utf8')); }
  catch (e) { if (e.code === 'ENOENT') return fallback; throw new Error('데이터 파일이 손상되었거나 읽을 수 없습니다. 파일을 확인하세요.'); }
}
async function bodyJson(req) {
  if (!req.headers['content-type']?.startsWith('application/json')) throw new InputError('Content-Type: application/json이 필요합니다.', 415);
  const chunks = []; let size = 0;
  for await (const chunk of req) { size += chunk.length; if (size > 256 * 1024) throw new InputError('요청이 너무 큽니다.', 413); chunks.push(chunk); }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new InputError('올바른 JSON을 보내세요.'); }
}
function validDate(d) {
  return typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d)) && new Date(d).toISOString().slice(0, 10) === d;
}

export async function createApp({ dataDir = path.join(ROOT, 'data'), recommendationOptions, yoloOptions = {} } = {}) {
  const spaces = await readJson(path.join(dataDir, 'spaces.json'), []);
  if (!spaces.length || new Set(spaces.map(s => s.id)).size !== spaces.length) throw new Error('공간 목록이 비어 있거나 ID가 중복되었습니다.');
  const observationsFile = path.join(dataDir, 'observations.json');
  let writes = Promise.resolve();
  async function appendObservation(item) {
    const run = writes.then(async () => {
      const observations = await readJson(observationsFile, []);
      observations.push(item);
      await fs.writeFile(observationsFile + '.tmp', JSON.stringify(observations, null, 2));
      await fs.rename(observationsFile + '.tmp', observationsFile);
    });
    writes = run.catch(() => {});
    await run;
  }
  async function recordObservation(b) {
    if (!b || !spaces.some(s => s.id === b.spaceId)) throw new InputError('측정한 공간을 지정하세요.');
    if (!Number.isInteger(b.count) || b.count < 0 || b.count > 100000) throw new InputError('재실 인원은 0 이상의 정수여야 합니다.');
    if (!validDate(b.localDate) || !timePattern.test(b.localTime)) throw new InputError('측정 날짜와 HH:mm 시간을 확인하세요.');
    if (!['manual', 'webcam', 'yolo'].includes(b.source)) throw new InputError('수동, 브라우저 웹캠 또는 YOLO 출처를 지정하세요.');
    const observation = { id: randomUUID(), spaceId: b.spaceId, count: b.count, localDate: b.localDate, localTime: b.localTime, source: b.source, savedAt: new Date().toISOString() };
    if (b.source === 'yolo') {
      if (!Number.isInteger(b.cameraIndex) || b.cameraIndex < 0 || b.cameraIndex > 20 || !Number.isFinite(b.confidence) || b.confidence < .05 || b.confidence > .95 || !Number.isFinite(Date.parse(b.observedAt))) throw new InputError('YOLO 관측 메타데이터를 확인하세요.');
      Object.assign(observation, { detector: 'yolov8n', cameraIndex: b.cameraIndex, confidence: b.confidence, observedAt: b.observedAt });
    }
    await appendObservation(observation);
    return observation;
  }
  const yolo = createYoloController({ root: ROOT, spaces, saveObservation: recordObservation, ...yoloOptions });
  async function staticFile(res, pathname) {
    let base = path.join(ROOT, 'public'), relative = pathname === '/' ? 'index.html' : pathname.slice(1);
    if (pathname.startsWith('/vendor/three/')) { base = path.join(ROOT, 'node_modules', 'three'); relative = pathname.slice('/vendor/three/'.length); }
    else if (pathname.startsWith('/vendor/vision/')) { base = path.join(ROOT, 'node_modules', '@mediapipe', 'tasks-vision'); relative = pathname.slice('/vendor/vision/'.length); }
    else if (pathname.startsWith('/vendor/')) return json(res, 404, { error: '파일이 없습니다.' });
    const target = path.resolve(base, relative);
    if (!target.startsWith(base + path.sep) || relative.split(/[\\/]/).some(p => p.startsWith('.'))) return json(res, 403, { error: '접근할 수 없습니다.' });
    try {
      const file = await fs.readFile(target);
      res.writeHead(200, { 'Content-Type': mime[path.extname(target)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
      res.end(file);
    } catch (e) {
      if (e.code !== 'ENOENT' && e.code !== 'EISDIR') throw e;
      json(res, 404, { error: pathname.startsWith('/vendor/') ? '의존성 파일이 없습니다. 프로젝트 폴더에서 npm.cmd install을 실행하세요.' : '파일이 없습니다.' });
    }
  }
  const app = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const requestHost = new URL('http://' + req.headers.host).hostname;
      if (!['localhost','127.0.0.1','[::1]'].includes(requestHost)) throw new InputError('localhost에서 접속하세요.', 403);
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        const origin = req.headers.origin;
        if (origin && new URL(origin).host !== req.headers.host) throw new InputError('다른 출처의 요청은 허용하지 않습니다.', 403);
      }
      if (url.pathname === '/api/health' && req.method === 'GET') return json(res, 200, { ok: true, version: '2.1.0', spaces: spaces.length, yoloSupported: true, aiConfigured: Boolean(recommendationOptions?.apiKey ?? process.env.OPENAI_API_KEY) });
      if (url.pathname === '/api/spaces' && req.method === 'GET') return json(res, 200, spaces);
      if (url.pathname === '/api/yolo/status' && req.method === 'GET') return json(res, 200, yolo.status());
      if (url.pathname.startsWith('/api/yolo/') && req.method === 'POST') {
        const body = await bodyJson(req);
        if (url.pathname === '/api/yolo/start') return json(res, 202, await yolo.start(body));
        if (url.pathname === '/api/yolo/stop') return json(res, 200, yolo.stop());
        if (url.pathname === '/api/yolo/heartbeat') return json(res, 200, yolo.heartbeat());
        if (url.pathname === '/api/yolo/capture') return json(res, 201, await yolo.capture());
        if (url.pathname === '/api/yolo/auto-save') return json(res, 200, yolo.setAutoSave(body?.enabled));
      }
      if (['/api/analyze', '/api/recommend'].includes(url.pathname) && req.method === 'POST') {
        const input = normalizeInput(await bodyJson(req), spaces);
        const analysis = analyze(input);
        return json(res, 200, url.pathname === '/api/analyze' ? { input, analysis } : await recommend(input, analysis, recommendationOptions));
      }
      if (url.pathname === '/api/observations' && req.method === 'POST') {
        const observation = await recordObservation(await bodyJson(req));
        return json(res, 201, { ok: true, observation });
      }
      if (url.pathname === '/api/observations' && req.method === 'GET') {
        await writes;
        const observations = await readJson(observationsFile, []);
        const date = url.searchParams.get('date'), referenceId = url.searchParams.get('referenceId'), targetId = url.searchParams.get('targetId');
        if (!validDate(date) || !spaces.some(s => s.id === referenceId) || !spaces.some(s => s.id === targetId) || referenceId === targetId) throw new InputError('날짜와 서로 다른 두 공간을 지정하세요.');
        return json(res, 200, { date, series: aggregateObservations(observations, referenceId, targetId, date), method: '선택 날짜·시간별 관측 스냅샷 평균. 합계 아님. 결측은 null.' });
      }
      if (url.pathname.startsWith('/api/')) return json(res, 404, { error: 'API 경로 또는 요청 방식을 확인하세요.' });
      if (!['GET', 'HEAD'].includes(req.method)) return json(res, 405, { error: 'Method not allowed' });
      await staticFile(res, decodeURIComponent(url.pathname));
    } catch (e) {
      console.error(e.message);
      if (!res.headersSent) json(res, e.status || 500, { error: e.status ? e.message : '서버 처리 오류입니다. 터미널과 데이터 파일을 확인하세요.' });
      else res.end();
    }
  });
  app.yoloShutdown = () => yolo.dispose();
  app.on('close', app.yoloShutdown);
  return app;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 3000);
  const app = await createApp();
  for (const signal of ['SIGINT','SIGTERM']) process.once(signal, () => { app.yoloShutdown(); app.close(); });
  app.on('error', error => {
    console.error(error.code === 'EADDRINUSE' ? '포트 ' + port + '이 사용 중입니다. 기존 서버 터미널에서 Ctrl+C 후 다시 실행하거나 PORT를 변경하세요.' : error.message);
    process.exitCode = 1;
  });
  app.listen(port, '127.0.0.1', () => console.log('학교 공간 연구실 v2.1 · http://localhost:' + app.address().port + '\n종료: Ctrl+C · AI: ' + (process.env.OPENAI_API_KEY ? 'OpenAI 설정됨' : '로컬 규칙 (API 키 미설정)')));
}

