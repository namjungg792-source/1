import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { PassThrough } from 'node:stream';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createYoloController } from '../lib/yolo-controller.mjs';
import { createApp } from '../server.mjs';

const PREFIX='@@PEOPLE_COUNTER@@';
function worker(){
  const p=new EventEmitter();p.stdin=new PassThrough();p.stdout=new PassThrough();p.stderr=new PassThrough();
  p.kill=()=>p.emit('close',1);
  p.send=e=>p.stdout.write(PREFIX+JSON.stringify(e)+'\n');
  return p;
}
const config={spaceId:'A',cameraIndex:1,confidence:.5,autoSave:false};
const tick=()=>new Promise(r=>setImmediate(r));
function fixture(t,extra={}){
  const child=worker(),saved=[],spawns=[];
  let time=Date.parse('2026-10-01T09:00:00+09:00');
  const c=createYoloController({root:process.cwd(),spaces:[{id:'A'},{id:'B'}],spawnImpl:(...args)=>{spawns.push(args);return child;},
    resolvePython:async()=>({command:'test-python',prefix:[]}),now:()=>time,
    saveObservation:async o=>{saved.push(o);return {...o,savedAt:new Date(time).toISOString()};},...extra});
  t.after(()=>{c.dispose();child.emit('close',0);});
  return {c,child,saved,spawns,advance:ms=>time+=ms,event:(count,extra={})=>child.send({event:'count',count,localDate:'2026-10-01',localTime:'09:00',observedAt:new Date(time).toISOString(),...extra})};
}

test('YOLO rejects invalid config before spawning and uses fixed arguments without shell',async t=>{
  const f=fixture(t);
  for(const patch of [{spaceId:'unknown'},{cameraIndex:'1 & whoami'},{cameraIndex:-1},{cameraIndex:1.5},{confidence:NaN},{confidence:0},{autoSave:'yes'}])
    await assert.rejects(f.c.start({...config,...patch}));
  assert.equal(f.spawns.length,0);
  await f.c.start(config);
  const [command,args,opts]=f.spawns[0];
  assert.equal(command,'test-python');assert.equal(opts.shell,false);assert.ok(args.includes('--managed'));
  assert.deepEqual(args.slice(-4),['--camera','1','--confidence','0.5']);
  await assert.rejects(f.c.start(config),{status:409});
});

test('no observation before first frame; real zero is saved with capture metadata; stale frames cannot be saved',async t=>{
  const f=fixture(t);await f.c.start(config);
  assert.equal(f.c.status().count,null);await assert.rejects(f.c.capture(),{status:409});
  f.event(0);assert.equal(f.c.status().count,0);await f.c.capture();
  assert.equal(f.saved.length,1);
  assert.deepEqual(f.saved[0],{spaceId:'A',count:0,source:'yolo',detector:'yolov8n',cameraIndex:1,confidence:.5,localDate:'2026-10-01',localTime:'09:00',observedAt:'2026-10-01T00:00:00.000Z'});
  f.advance(11000);await assert.rejects(f.c.capture(),{status:409});assert.equal(f.c.status().count,null);
  f.event(-1);f.event(2,{observedAt:'2020-01-01T00:00:00Z'});assert.equal(f.saved.length,1);
});

test('automatic recording is opt-in and rate-limited; stop clears count and ignores late frames',async t=>{
  const f=fixture(t);await f.c.start(config);f.event(2);await tick();assert.equal(f.saved.length,0);
  f.c.setAutoSave(true);f.event(3);await tick();assert.equal(f.saved.length,1);
  f.advance(4000);f.event(4);await tick();assert.equal(f.saved.length,1);
  f.advance(1000);f.event(5);await tick();assert.equal(f.saved.length,2);
  let stdin='';f.child.stdin.on('data',chunk=>stdin+=chunk);
  f.c.stop();f.event(100);await tick();
  assert.equal(f.c.status().count,null);assert.equal(f.saved.length,2);assert.ok(stdin.includes('"command":"stop"'));
  f.child.emit('close',0);assert.equal(f.c.status().active,false);
});

test('failed saves disable auto recording and concurrent saves do not duplicate a snapshot',async t=>{
  let rejectSave;
  const f=fixture(t,{saveObservation:()=>new Promise((_,reject)=>rejectSave=reject)});
  await f.c.start({...config,autoSave:true});f.event(4);
  await assert.rejects(f.c.capture(),{status:409});
  rejectSave(new Error('disk full'));await tick();
  assert.equal(f.c.status().autoSave,false);assert.equal(f.c.status().saveError,'disk full');assert.equal(f.c.status().savedCount,0);
});

test('missing Python and camera errors remain actionable after the process closes',async t=>{
  const f=fixture(t);await f.c.start(config);
  f.child.emit('error',new Error('spawn ENOENT'));f.child.emit('close',-1);
  assert.equal(f.c.status().active,false);assert.match(f.c.status().message,/SETUP_YOLO/);
  await f.c.start(config);
  f.child.send({event:'error',message:'웹캠을 열 수 없습니다.'});f.child.send({event:'stopped'});f.child.emit('close',1);
  assert.equal(f.c.status().phase,'error');assert.match(f.c.status().message,/웹캠/);
});

test('stop during async Python lookup cancels launch',async t=>{
  let resolveLookup;
  const f=fixture(t,{resolvePython:()=>new Promise(resolve=>resolveLookup=resolve)});
  const pending=f.c.start(config);f.c.stop();resolveLookup({command:'test-python',prefix:[]});
  await pending;assert.equal(f.spawns.length,0);assert.equal(f.c.status().active,false);
});

test('lost browser heartbeat releases camera process',async t=>{
  const f=fixture(t,{leaseMs:1});await f.c.start(config);f.advance(2000);
  await new Promise(r=>setTimeout(r,2100));assert.equal(f.c.status().phase,'stopping');
});

test('YOLO HTTP capture persists counts and is included in the existing hourly comparison',async t=>{
  const temp=await fs.mkdtemp(path.join(os.tmpdir(),'school-yolo-test-'));
  await fs.writeFile(path.join(temp,'spaces.json'),JSON.stringify([{id:'A',name:'기준'},{id:'B',name:'대상'}]));
  const child=worker();
  const app=await createApp({dataDir:temp,yoloOptions:{spawnImpl:()=>child,resolvePython:async()=>({command:'fake',prefix:[]})}});
  await new Promise(resolve=>app.listen(0,'127.0.0.1',resolve));
  t.after(async()=>{app.yoloShutdown();child.emit('close',0);await new Promise(resolve=>app.close(resolve));await fs.rm(temp,{recursive:true,force:true});});
  const url='http://127.0.0.1:'+app.address().port;
  const post=(route,body={})=>fetch(url+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  assert.equal((await post('/api/yolo/start',config)).status,202);
  assert.equal((await post('/api/yolo/capture')).status,409);
  child.send({event:'count',count:6,localDate:'2026-10-01',localTime:'09:15',observedAt:new Date().toISOString()});
  assert.equal((await post('/api/yolo/capture')).status,201);
  assert.equal((await post('/api/observations',{spaceId:'B',count:2,localDate:'2026-10-01',localTime:'09:45',source:'manual'})).status,201);
  const stored=JSON.parse(await fs.readFile(path.join(temp,'observations.json'),'utf8'));
  assert.equal(stored[0].source,'yolo');assert.equal(stored[0].detector,'yolov8n');assert.equal(stored[0].count,6);assert.equal(stored[0].image,undefined);
  const result=await (await fetch(url+'/api/observations?date=2026-10-01&referenceId=A&targetId=B')).json();
  assert.equal(result.series[0].reference,6);assert.equal(result.series[0].target,2);
  const blocked=await fetch(url+'/api/yolo/start',{method:'POST',headers:{'Content-Type':'application/json',Origin:'https://example.org'},body:JSON.stringify(config)});
  assert.equal(blocked.status,403);
  assert.equal((await fetch(url+'/yolo.js')).status,200);
  assert.equal((await post('/api/yolo/stop')).status,200);
});
