import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { normalizeInput, analyze, aggregateObservations } from '../lib/analysis.mjs';
import { recommend, localRecommendations, validateRecommendations, parseResponse, SYSTEM_PROMPT } from '../lib/recommendations.mjs';
import { createApp } from '../server.mjs';
import { layoutSpaces } from '../public/school-config.js';
const spaces=JSON.parse(await fs.readFile(new URL('../data/spaces.json',import.meta.url),'utf8'));
const base={referenceId:'HONGIK-2-LIBRARY',targetId:'MAIN-4-11',provenance:'manual',existingFacilities:[],series:[{time:'10:00',reference:18,target:1},{time:'09:00',reference:12,target:2},{time:'11:00',reference:15,target:3}]};
const input=()=>normalizeInput(structuredClone(base),spaces);

test('statistics use only counts, sort times, and report all ties',()=>{
  const data=input(),a=analyze(data);
  assert.equal(a.reference.average,15);assert.equal(a.target.average,2);assert.equal(a.target.min,1);assert.equal(a.target.max,3);
  assert.deepEqual(a.target.peakHours,['11:00']);assert.deepEqual(a.target.lowHours,['10:00']);assert.equal(a.comparison.averageGap,13);
  assert.deepEqual(data.series.map(r=>r.time),['09:00','10:00','11:00']);
  for(const key of ['capacity','access','visibility','openness','flexibility','spatialAffordance','reactivationPriority'])assert.equal(JSON.stringify(a).includes('"'+key+'"'),false);
});
test('missing values are not zeros and paired differences exclude missing hours',()=>{
  const d=input();d.series.push({time:'12:00',reference:100,target:null});const a=analyze(d);
  assert.equal(a.reference.average,36.25);assert.equal(a.target.average,2);assert.equal(a.target.missingCount,1);assert.equal(a.comparison.averageGap,13);assert.equal(a.differences.length,3);
});
test('all zero and reversed labels remain finite and are explicitly qualified',()=>{
  const d=input();d.series.forEach(r=>{r.reference=0;r.target=0;});let a=analyze(d);
  assert.equal(a.comparison.targetToReferenceRatio,null);assert.equal(a.target.lowHours.length,3);assert.equal(a.target.peakHours.length,3);assert.ok(a.warnings.some(w=>w.includes('동일')||w.includes('같습니다')));
  d.series.forEach(r=>r.target=20);a=analyze(d);assert.equal(a.comparison.averageGap,-20);assert.ok(a.warnings.some(w=>w.includes('재확인')));
});
test('reject malformed, negative, duplicate, unaligned, and same-space inputs',()=>{
  for(const edit of [b=>b.series[0].reference=-1,b=>b.series[0].target='2',b=>b.series[0].time='25:00',b=>b.series[0].time='09:00',b=>b.targetId=b.referenceId,b=>b.series.forEach(r=>r.target=null),b=>b.series[0].reference=undefined,b=>b.existingFacilities='도서관']){
    const b=structuredClone(base);edit(b);assert.throws(()=>normalizeInput(b,spaces));
  }
});
test('server prompt input strips invented legacy metrics and geometry',()=>{
  const b={...base,access:1,visibility:.9,geometry:{width:1000},capacity:30};const d=normalizeInput(b,spaces);
  assert.equal(d.access,undefined);assert.equal(d.geometry,undefined);assert.equal(d.reference.capacity,undefined);assert.equal(d.manualProperties.source,'not-provided');
  assert.ok(SYSTEM_PROMPT.includes('개념적 관점'));assert.ok(SYSTEM_PROMPT.includes('정확히 5개'));
});
test('fallback provides exactly five complete, differentiated alternatives',async()=>{
  const d=input();d.existingFacilities=['도서관','휴게실','동아리실'];const a=analyze(d),r=await recommend(d,a,{apiKey:''});
  assert.equal(r.source,'local-rules');assert.equal(r.options.length,5);assert.equal(new Set(r.options.map(o=>o.name)).size,5);validateRecommendations(r.options?{summary:r.summary,options:r.options}:r,d);
  assert.ok(r.options[0].facilityDifferentiation.includes('도서관'));assert.ok(r.options[1].facilityDifferentiation.includes('휴게실'));
  r.options.forEach(o=>{assert.ok(o.requiredConditions.length);assert.ok(o.advantages.length);assert.ok(o.disadvantages.length);assert.deepEqual(o.suitableHours,['10:00']);});
});
test('invalid AI option count, empty required fields, invented hours, and duplicates rejected',()=>{
  for(const edit of [r=>r.options.pop(),r=>r.options[0].schoolFit='',r=>r.options[0].suitableHours=['23:00'],r=>r.options[1].name=r.options[0].name]){
    const d=input(),r=structuredClone(localRecommendations(d,analyze(d)));edit(r);assert.throws(()=>validateRecommendations(r,d));
  }
});
test('Responses REST output content is parsed (not SDK-only output_text)',()=>{
  assert.deepEqual(parseResponse({status:'completed',output:[{type:'reasoning',summary:[]},{type:'message',content:[{type:'output_text',text:'{"ok":true}'}]}]}),{ok:true});
  assert.throws(()=>parseResponse({status:'incomplete',output:[]}));assert.throws(()=>parseResponse({output:[{type:'message',content:[{type:'refusal'}]}]}));
});
test('OpenAI request uses strict JSON schema and only count/manual inputs',async()=>{
  const d=input(),a=analyze(d),value=localRecommendations(d,a);let sent;
  const r=await recommend(d,a,{apiKey:'test-only',fetchImpl:async(url,opts)=>{sent=JSON.parse(opts.body);assert.equal(url,'https://api.openai.com/v1/responses');return {ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(value)}]}]})};}});
  assert.equal(r.source,'openai');assert.equal(sent.store,false);assert.equal(sent.text.format.strict,true);assert.equal(sent.text.format.schema.properties.options.minItems,5);assert.equal(sent.text.format.schema.properties.options.maxItems,5);
  assert.equal(JSON.parse(sent.input).reference.area,undefined);
});
test('API failure and invalid AI output fall back transparently',async()=>{
  const d=input(),a=analyze(d);
  for(const fetchImpl of [async()=>({ok:false,status:429}),async()=>({ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:'{}'}]}]})}),async()=>{throw new Error('network unavailable');}]){
    const r=await recommend(d,a,{apiKey:'test-only',fetchImpl});assert.equal(r.source,'local-rules');assert.equal(r.options.length,5);assert.ok(r.warning.includes('실패'));
  }
});
test('observation buckets average snapshots and keep days and missing spaces separate',()=>{
  const obs=[{spaceId:'A',count:2,localDate:'2026-09-30',localTime:'09:00'},{spaceId:'A',count:4,localDate:'2026-09-30',localTime:'09:05'},{spaceId:'B',count:8,localDate:'2026-09-30',localTime:'10:05'},{spaceId:'A',count:99,localDate:'2026-09-29',localTime:'09:05'}];
  assert.deepEqual(aggregateObservations(obs,'A','B','2026-09-30'),[{time:'09:00',reference:3,target:null,referenceSamples:2,targetSamples:0},{time:'10:00',reference:null,target:8,referenceSamples:0,targetSamples:1}]);
});
test('supplied plan maps 118 spaces with a four-storey main wing and five-storey west wing',()=>{
  const layout=layoutSpaces(spaces);assert.equal(layout.length,118);assert.equal(new Set(layout.map(s=>s.id)).size,118);
  assert.equal(Math.max(...layout.filter(s=>s.building==='MAIN').map(s=>s.floor)),4);assert.equal(Math.max(...layout.filter(s=>s.building==='ANNEX').map(s=>s.floor)),5);assert.equal(layout.find(s=>s.id==='MAIN-4-11').name,'진로활동실');assert.equal(layout.find(s=>s.id==='HONGIK-2-LIBRARY').name,'도서관');
  layout.forEach(s=>assert.ok(s.w>0&&s.d>0&&Number.isFinite(s.x)&&Number.isFinite(s.z)));
});

test('HTTP smoke, static imports, observations persistence, validation, and local request boundary',async(t)=>{
  const temp=await fs.mkdtemp(path.join(os.tmpdir(),'school-space-test-'));
  await fs.writeFile(path.join(temp,'spaces.json'),JSON.stringify(spaces));await fs.writeFile(path.join(temp,'observations.json'),'[]');
  const app=await createApp({dataDir:temp,recommendationOptions:{apiKey:''}});await new Promise(resolve=>app.listen(0,'127.0.0.1',resolve));
  const baseURL='http://127.0.0.1:'+app.address().port;
  t.after(async()=>{await new Promise(resolve=>app.close(resolve));await fs.rm(temp,{recursive:true,force:true});});
  for(const route of ['/','/app.js','/school.js','/camera.js','/school-config.js','/vendor/three/build/three.module.js','/vendor/three/build/three.core.js','/vendor/three/examples/jsm/controls/OrbitControls.js','/vendor/vision/vision_bundle.mjs','/vendor/vision/wasm/vision_wasm_internal.wasm','/public-nope']){
    const r=await fetch(baseURL+route);assert.equal(r.status,route==='/public-nope'?404:200,route);await r.arrayBuffer();
  }
  const wasm=await fetch(baseURL+'/vendor/vision/wasm/vision_wasm_internal.wasm');assert.equal(wasm.headers.get('content-type'),'application/wasm');await wasm.arrayBuffer();
  for(const route of ['/server.mjs','/data/spaces.json','/.env','/vendor/three/..%5c..%5c..%5cserver.mjs']){const r=await fetch(baseURL+route);assert.ok([403,404].includes(r.status),route);await r.text();}
  const post=(route,body,headers={})=>fetch(baseURL+route,{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(body)});
  assert.equal((await (await fetch(baseURL+'/api/health')).json()).spaces,118);
  const rec=await post('/api/recommend',base);assert.equal(rec.status,200);assert.equal((await rec.json()).options.length,5);
  assert.equal((await post('/api/analyze',{...base,targetId:base.referenceId})).status,400);
  assert.equal((await post('/api/recommend',base,{Origin:'https://example.org'})).status,403);
  const observation={spaceId:base.referenceId,localDate:'2026-09-30',localTime:'09:00',count:4,source:'manual'};
  const writes=await Promise.all([post('/api/observations',observation),post('/api/observations',{...observation,count:8}),post('/api/observations',{...observation,spaceId:base.targetId,count:2})]);writes.forEach(r=>assert.equal(r.status,201));
  assert.equal((await post('/api/observations',{...observation,localDate:'2026-02-30'})).status,400);
  assert.equal((await post('/api/observations',{...observation,count:1.5})).status,400);
  const stored=JSON.parse(await fs.readFile(path.join(temp,'observations.json'),'utf8'));assert.equal(stored.length,3);assert.ok(stored.every(o=>o.id&&o.savedAt&&!('image'in o)));
  const grouped=await (await fetch(baseURL+'/api/observations?date=2026-09-30&referenceId='+base.referenceId+'&targetId='+base.targetId)).json();assert.equal(grouped.series[0].reference,6);assert.equal(grouped.series[0].target,2);
});
