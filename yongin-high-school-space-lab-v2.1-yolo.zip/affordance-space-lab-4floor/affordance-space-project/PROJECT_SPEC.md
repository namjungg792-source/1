# 구현 명세 v2

원본 affordance-space-lab-4floor/affordance-space-project를 기반으로 개편했습니다. 이전의 임의 공간 점수와 이용률 공식, 카메라 화면을 여러 교실에 자동 배정하는 로직, 가짜 이동 궤적 수는 제거했습니다.

데이터 흐름: 시간별 재실 인원 → Node.js 기술통계 → OpenAI 엄격한 JSON Schema 또는 표시된 로컬 규칙 → 정확히 5개 대안 카드 → JSON 다운로드.

`POST /api/analyze`, `POST /api/recommend` 입력:

```json
{
  "referenceId": "HONGIK-2-LIBRARY",
  "targetId": "MAIN-4-11",
  "provenance": "manual",
  "series": [
    {"time":"09:00","reference":12,"target":2},
    {"time":"10:00","reference":18,"target":1}
  ],
  "existingFacilities": ["도서관", "열람실"],
  "manualProperties": "사용자가 직접 확인한 조건만 입력",
  "observationContext": "같은 날짜와 관찰 간격"
}
```

결측 인원은 `null`, 0명은 `0`. 공통 시간 최소 2개. 두 공간의 평균은 각 공간의 유효 시간대 단순 평균, 평균 차이는 공통 시간만 사용. 최고/최저 동률 시간은 모두 출력. 기준 평균 0에서는 비율 `null`. 대상이 더 많이 이용되거나 전체 시간이 동일한 경우 경고.

추천 결과: `schemaVersion`, `source(openai|local-rules)`, `warning`, `provenance`, `input`, `analysis`, `conceptualLens`, `summary`, `options`.

각 option의 필수 키: `name`, `use`, `studentBehaviors`, `patternFit`, `advantages`, `disadvantages`, `requiredConditions`, `schoolFit`, `suitableHours`, `facilityDifferentiation`, `noiseAndCongestion`. 정확히 5개·서로 다른 이름·실제 관측 시간만 검증. 학교 적합성과 물리적 실행 가능성은 현장 검토가 필요함.

관측 기록: `POST /api/observations`에 `spaceId`, `count`(정수), `localDate(YYYY-MM-DD)`, `localTime(HH:mm)`, `source(manual|webcam)`. 서버는 `id`, `savedAt` 부여. 파일 쓰기는 직렬화하고 임시 파일 후 교체. 날짜별 `GET /api/observations?date=...&referenceId=...&targetId=...`는 시간별 스냅샷 평균과 관측 수를 반환하며 날짜를 혼합하지 않음.

정적 파일: `/public` 내용, 명시적인 `/vendor/three/`와 `/vendor/vision/` 패키지 경로만 제공. 서버·.env·데이터 파일은 정적 노출하지 않음. JavaScript·WASM MIME 명시. 서버는 127.0.0.1에 바인딩하며 교차 출처 쓰기 요청 차단. 공개 인터넷 서비스용 인증 서버는 아님.
