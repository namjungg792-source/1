import contextlib
from datetime import datetime, timezone
import io
import json
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch
import people_counter as pc

class CounterTests(unittest.TestCase):
    def test_bad_config(self):
        with contextlib.redirect_stderr(io.StringIO()):
            for argv in [["--camera", "-1"], ["--confidence", "nan"], ["--confidence", "0"], ["--managed", "--self-test"]]:
                with self.assertRaises(SystemExit):
                    pc.parse_args(argv)

    def test_zero_and_timestamp(self):
        self.assertEqual(pc.count_people(None), 0)
        self.assertEqual(pc.count_people([1, 2]), 2)
        sample = pc.sample_event(0, datetime(2026, 10, 1, 9, 15, tzinfo=timezone.utc))
        self.assertEqual(sample["localTime"], "09:15")
        self.assertEqual(sample["localDate"], "2026-10-01")

    def fake(self, boxes=None, frame_ok=True):
        cap = Mock()
        cap.isOpened.return_value = True
        cap.read.return_value = (frame_ok, object())
        cv = Mock()
        cv.VideoCapture.return_value = cap
        cv.waitKey.return_value = ord("q")
        model = Mock()
        model.predict.return_value = [SimpleNamespace(boxes=boxes)]
        yolo = Mock(return_value=model)
        return cap, cv, model, yolo

    def test_original_person_filter_confidence_box_and_q_release(self):
        box = SimpleNamespace(xyxy=[[1.2, 2.1, 30.1, 40.5]], conf=[0.85])
        cap, cv, model, yolo = self.fake([box])
        with patch.object(pc, "emit") as emit:
            self.assertEqual(pc.run(pc.parse_args(["--camera", "1", "--confidence", "0.6"]), cv, yolo), 0)
        self.assertEqual(cv.VideoCapture.call_args.args[0], 1)
        self.assertEqual(model.predict.call_args.kwargs["classes"], [0])
        self.assertEqual(model.predict.call_args.kwargs["conf"], 0.6)
        self.assertEqual(model.predict.call_args.kwargs["save"], False)
        cv.rectangle.assert_called_once()
        cap.release.assert_called_once()
        cv.destroyAllWindows.assert_called_once()
        counts = [c.kwargs["count"] for c in emit.call_args_list if c.args[0] == "count"]
        self.assertEqual(counts, [1])

    def test_no_boxes_does_not_crash(self):
        cap, cv, model, yolo = self.fake()
        with patch.object(pc, "emit") as emit:
            self.assertEqual(pc.run(pc.parse_args([]), cv, yolo), 0)
        self.assertTrue(any(c.args[0] == "count" and c.kwargs["count"] == 0 for c in emit.call_args_list))
        cap.release.assert_called_once()

    def test_frame_failure_releases_camera_without_false_zero(self):
        cap, cv, model, yolo = self.fake(frame_ok=False)
        with patch.object(pc, "emit") as emit:
            with self.assertRaisesRegex(RuntimeError, "프레임"):
                pc.run(pc.parse_args([]), cv, yolo)
        self.assertFalse(any(c.args[0] == "count" for c in emit.call_args_list))
        cap.release.assert_called_once()

if __name__ == "__main__":
    unittest.main()
