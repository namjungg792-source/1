@echo off
setlocal
cd /d "%~dp0"
where npm.cmd >nul 2>nul
if errorlevel 1 (
  echo Node.js 20 or newer is required. Install Node.js, then reopen this file.
  pause
  exit /b 1
)
if not exist "node_modules\three\build\three.module.js" (
  call npm.cmd install
  if errorlevel 1 (
    pause
    exit /b 1
  )
)
echo Open http://localhost:3000 in your browser after the server starts.
call npm.cmd start
pause
