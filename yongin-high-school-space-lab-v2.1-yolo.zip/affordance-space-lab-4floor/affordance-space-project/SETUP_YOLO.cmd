@echo off
setlocal
cd /d "%~dp0"
set "YOLO_ENV=%LOCALAPPDATA%\SchoolSpaceLab\yolo-python"
echo Installing YOLO in "%YOLO_ENV%"...
echo A short, isolated path avoids Windows long-path installation errors.
if exist "%YOLO_ENV%\Scripts\python.exe" goto :install
where py >nul 2>nul
if not errorlevel 1 (
  py -3.12 -m venv "%YOLO_ENV%"
) else (
  python -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,12) else 1)"
  if errorlevel 1 goto :error
  python -m venv "%YOLO_ENV%"
)
if errorlevel 1 goto :error
:install
"%YOLO_ENV%\Scripts\python.exe" -m pip install -r requirements-yolo.txt
if errorlevel 1 goto :error
"%YOLO_ENV%\Scripts\python.exe" people_counter.py --check
if errorlevel 1 goto :error
echo.
echo YOLO ready. Run npm.cmd start, then select YOLOv8n in the web app.
echo The model is bundled. If missing, the first camera start downloads it.
pause
exit /b 0
:error
echo.
echo Setup failed. Install Python 3.12 (64-bit) and check the internet connection.
echo Enable the Python launcher or "Add python.exe to PATH" during installation.
pause
exit /b 1
