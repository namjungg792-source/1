// Lazy loaded only after the user presses Camera Start. A failed vision dependency
// must never prevent the school explorer or the analysis UI from loading.
export function createPeopleCamera({ video, canvas, onStatus, onCount, onFailure }) {
  let stream = null, detector = null, running = false, frame = 0, lastVideoTime = -1, lastRun = 0, count = null;
  function stop() {
    running = false; cancelAnimationFrame(frame); stream?.getTracks().forEach(track => track.stop()); stream = null;
    video.srcObject = null; count = null; lastVideoTime = -1;
    canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
    onStatus('카메라를 중지했습니다. 저장된 인원 기록은 유지됩니다.');
  }
  function draw(detections) {
    const w = video.videoWidth, h = video.videoHeight;
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
    const ctx = canvas.getContext('2d');ctx.clearRect(0,0,w,h);ctx.strokeStyle='#000000';ctx.lineWidth=3;
    for(const d of detections) {const b=d.boundingBox;ctx.strokeRect(b.originX,b.originY,b.width,b.height);}
  }
  function loop(now) {
    if(!running)return;
    if(video.readyState>=2 && video.currentTime!==lastVideoTime && now-lastRun>=200) {
      lastVideoTime=video.currentTime;lastRun=now;
      try {
        const result=detector.detectForVideo(video,now);
        const people=result.detections.filter(d=>d.categories?.some(c=>c.categoryName==='person'));
        count=people.length;draw(people);onCount(count);
      } catch(e) { stop(); onFailure('사람 탐지를 중지했습니다: '+e.message); return; }
    }
    frame=requestAnimationFrame(loop);
  }
  async function start() {
    if(running)return;
    if(!navigator.mediaDevices?.getUserMedia)throw new Error('localhost 또는 HTTPS에서 카메라를 실행하세요.');
    try {
      onStatus('사람 탐지 모듈을 준비하고 있습니다…');
      if(!detector) {
        const {FilesetResolver,ObjectDetector}=await import('/vendor/vision/vision_bundle.mjs');
        const vision=await FilesetResolver.forVisionTasks('/vendor/vision/wasm');
        detector=await ObjectDetector.createFromOptions(vision,{
          baseOptions:{modelAssetPath:'/models/efficientdet_lite0.tflite',delegate:'CPU'},
          runningMode:'VIDEO',scoreThreshold:.45,maxResults:50,categoryAllowlist:['person']
        });
      }
      onStatus('카메라 권한을 기다리고 있습니다…');
      stream=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:1280},height:{ideal:720}},audio:false});
      stream.getVideoTracks()[0].addEventListener('ended',()=>{if(running){stop();onFailure('카메라 연결이 끝났습니다. 다시 시작해 주세요.');}});
      video.srcObject=stream;await video.play();
      lastVideoTime=-1;lastRun=0;running=true;onStatus('사람 탐지 중 · 약 5회/초 · 영상은 이 브라우저에서만 처리됩니다.');
      frame=requestAnimationFrame(loop);
    }catch(e){stop();throw e;}
  }
  return {start,stop,get count(){return count;}};
}
