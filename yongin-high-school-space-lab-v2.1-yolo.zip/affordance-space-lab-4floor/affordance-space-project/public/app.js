import { CAMPUS, EXISTING_FACILITIES } from './school-config.js';
import { createYoloUI } from './yolo.js';
const $ = id => document.getElementById(id);
const buildingName = id => CAMPUS.buildings.find(b => b.id === id)?.name || id;
const spaceLabel = s => `${buildingName(s.building)} ${s.floor}F · ${s.name}`;
const state = { spaces: [], selectedId: 'MAIN-4-11', floor: 'all', building: 'all', school: null, analysis: null, result: null, revision: 0, camera: null, cameraSpace: null, cameraReady: false, saving: false, lastAutoSave: 0 };
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const list = items => '<ul>' + items.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>';
const localDate = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const localTime = (d = new Date()) => `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
const sourceLabel = { demo: '예시 데이터 · 실제 측정 아님', manual: '직접 입력 · 미검증', observations: '저장된 관측 · 시간별 평균' };
let yoloUI;
async function api(url, body) {
  const response = await fetch(url, body === undefined ? {} : { method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify(body) });
  const value = await response.json(); if (!response.ok) throw new Error(value.error || '서버 요청 실패'); return value;
}
function showError(message) { $('globalError').textContent = message; $('globalError').hidden = !message; }
function log(message, error = false) { const p = document.createElement('p'); p.textContent = message; if (error) p.style.color = '#934b31'; $('captureLog').prepend(p); while ($('captureLog').children.length > 8) $('captureLog').lastChild.remove(); }
function clearResults(message = '입력이 바뀌었습니다. 이용 패턴을 다시 비교하세요.') {
  state.revision++; state.result = null; state.analysis = null; $('downloadBtn').disabled = true;
  $('recommendation').innerHTML = '<div class="empty-state"><span>5</span><div><h3>다섯 가지 가능성을 탐색하세요.</h3><p>' + esc(message) + '</p></div></div>';
  $('stats').replaceChildren(); $('chart').replaceChildren(); $('comparisonTable').replaceChildren(); $('analysisNotes').replaceChildren();
  $('patternSummary').textContent = message; $('inputMessage').textContent = message; state.school?.setData([]);
  const label = sourceLabel[$('provenance').value]; $('dataSourceBadge').textContent = $('provenance').value === 'demo' ? '예시' : '입력값'; $('comparisonSource').textContent = label;
}
function parseCSV(text) {
  const lines = text.trim().split(/\r?\n/).filter(line => line.trim());
  if (!lines.length) throw new Error('시간대별 데이터를 입력하세요.');
  if (/시간|time/i.test(lines[0])) lines.shift();
  return lines.map((line, i) => {
    const columns = line.includes('\t') ? line.split('\t') : line.includes(',') ? line.split(',') : line.trim().split(/\s+/);
    if (columns.length !== 3) throw new Error(`${i+1}행: 시간, 기준 인원, 대상 인원 세 칸으로 입력하세요.`);
    const [time, ref, target] = columns.map(x => x.trim());
    const count = value => { if (!value) return null; if (!/^\d+(\.\d+)?$/.test(value)) throw new Error(`${i+1}행: 인원을 0 이상의 수로 입력하세요.`); return Number(value); };
    return { time, reference: count(ref), target: count(target) };
  });
}
function requestInput() {
  return { referenceId: $('referenceId').value, targetId: $('targetId').value, series: parseCSV($('countsInput').value), provenance: $('provenance').value,
    existingFacilities: $('existingFacilities').value.split(/[,\n]/).map(x=>x.trim()).filter(Boolean), manualProperties: $('manualProperties').value,
    observationContext: $('observationContext').value };
}
function renderSpaces() {
  const spaces = state.spaces.filter(s => (state.floor === 'all' || s.floor === Number(state.floor)) && (state.building === 'all' || s.building === state.building));
  $('spaceCount').textContent = spaces.length + '개';
  $('spaceList').innerHTML = spaces.map(s => `<button data-id="${esc(s.id)}" class="${s.id===state.selectedId?'active':''}" aria-pressed="${s.id===state.selectedId}">${esc(spaceLabel(s))}</button>`).join('');
  const selected = state.spaces.find(s=>s.id===state.selectedId);
  $('selectedName').textContent = selected?.name || '—'; $('selectedMeta').textContent = selected ? `${buildingName(selected.building)} ${selected.floor}F · ${selected.type} · 2024 배치도 표기` : '';
}
function selectSpace(id) { state.selectedId = id; state.school?.highlight(id); renderSpaces(); }
function setFloor(value) {
  state.floor = value; state.school?.setFloor(value);
  for(const btn of $('floorTabs').querySelectorAll('button')) { btn.classList.toggle('active',btn.dataset.floor===value); btn.setAttribute('aria-pressed',btn.dataset.floor===value); }
  const candidate = state.spaces.find(s=>(value==='all'||s.floor===Number(value))&&(state.building==='all'||s.building===state.building));
  if(candidate && (value!=='all'||state.building!=='all')) selectSpace(candidate.id);
  $('sceneStatus').textContent = value==='all' ? '전체 층 · 드래그로 회전 · 휠로 확대' : value+'층 단면 · 개별 공간을 선택하세요'; renderSpaces();
}
function setBuilding(value) {
  state.building=value;const max=CAMPUS.buildings.find(b=>b.id===value)?.floors||5;
  if(state.floor!=='all'&&Number(state.floor)>max)state.floor='all';
  for(const button of $('floorTabs').querySelectorAll('button'))button.disabled=button.dataset.floor!=='all'&&Number(button.dataset.floor)>max;
  state.school?.setBuilding(value);setFloor(state.floor);
}
function hours(values) { return values.length ? values.join(', ') : '없음'; }
function drawChart(series) {
  const W=780,H=215,left=43,right=19,top=20,bottom=36;
  const max=Math.max(1,...series.flatMap(r=>[r.reference??0,r.target??0]));
  const ymax=Math.ceil(max/5)*5, x=i=>left+i*(W-left-right)/Math.max(series.length-1,1), y=v=>H-bottom-v/ymax*(H-top-bottom);
  let svg=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="기준과 대상의 시간대별 이용 인원 비교. 정확한 수치는 아래 표에서 확인할 수 있습니다.">`;
  for(let i=0;i<=4;i++){const v=ymax*i/4;svg+=`<line x1="${left}" x2="${W-right}" y1="${y(v)}" y2="${y(v)}" stroke="#e5eae1"/><text x="${left-11}" y="${y(v)+3}" text-anchor="end" fill="#819079" font-size="10">${Number(v.toFixed(1))}</text>`;}
  for(const [key,color,dashed]of [['reference','#245b4b',false],['target','#9aaf64',true]]){
    let segment=[];const flush=()=>{if(segment.length>1)svg+=`<polyline points="${segment.join(' ')}" fill="none" stroke="${color}" stroke-width="2.5" ${dashed?'stroke-dasharray="5 4"':''}/>`;segment=[];};
    series.forEach((r,i)=>{if(r[key]===null)flush();else segment.push(`${x(i)},${y(r[key])}`);});flush();
    series.forEach((r,i)=>{if(r[key]!==null)svg+=`<circle cx="${x(i)}" cy="${y(r[key])}" r="3.7" fill="white" stroke="${color}" stroke-width="2"><title>${esc(r.time)} ${key==='reference'?'기준':'대상'} ${r[key]}명</title></circle>`;});
  }
  series.forEach((r,i)=>{if(i%Math.max(1,Math.ceil(series.length/12))===0)svg+=`<text x="${x(i)}" y="${H-10}" text-anchor="middle" fill="#819079" font-size="10">${esc(r.time)}</text>`;});
  $('chart').innerHTML=svg+'</svg>';
}
function renderAnalysis(data) {
  state.analysis = data; const {analysis:a,input}=data, c=a.comparison;
  $('comparisonSource').textContent=sourceLabel[input.provenance];
  $('stats').innerHTML=[
    ['기준 공간 평균',a.reference.average,input.reference.name,`최대 ${a.reference.max}명 · 최소 ${a.reference.min}명`],
    ['대상 공간 평균',a.target.average,input.target.name,`최대 ${a.target.max}명 · 최소 ${a.target.min}명`],
    ['공통 시간 평균 차이',c.averageGap,'기준 − 대상',`${c.pairedCount}개 공통 관측 시간 비교`]
  ].map(([label,value,name,note])=>`<div class="stat-card"><div class="stat-label">${esc(label)} · ${esc(name)}</div><div class="stat-value">${value}<small>명</small></div><div class="stat-note">${esc(note)}</div></div>`).join('');
  drawChart(input.series);
  $('patternSummary').innerHTML=`<div class="pattern-row"><span>기준 최고</span><div><strong>${esc(hours(a.reference.peakHours))}</strong><small>${a.reference.max}명 · 최저 ${esc(hours(a.reference.lowHours))} (${a.reference.min}명)</small></div></div><div class="pattern-row"><span>대상 최고</span><div><strong>${esc(hours(a.target.peakHours))}</strong><small>${a.target.max}명 · 최저 ${esc(hours(a.target.lowHours))} (${a.target.min}명)</small></div></div><div class="pattern-row"><span>낮은 이용</span><div><strong>${esc(hours(a.target.nearEmptyHours))}</strong><small>대상 0~2명인 관측 시간 · 설명용 기준</small></div></div><div class="pattern-row"><span>차이 해석</span><div><strong>${c.averageGap>0?'공통 시간 평균에서 대상 인원이 더 적습니다.':'대상이 저이용인지 다시 확인해 주세요.'}</strong><small>최대 차이 ${c.largestGap}명 (${esc(hours(c.largestGapHours))}) · 이용 증가나 원인은 단정하지 않습니다.</small></div></div>`;
  $('comparisonTable').innerHTML='<table><thead><tr><th>시간</th><th>기준 (명)</th><th>대상 (명)</th><th>기준 − 대상</th></tr></thead><tbody>'+input.series.map(r=>`<tr><td>${esc(r.time)}</td><td>${r.reference??'결측'}</td><td>${r.target??'결측'}</td><td>${r.reference===null||r.target===null?'비교 불가':Number((r.reference-r.target).toFixed(2))}</td></tr>`).join('')+'</tbody></table>';
  $('analysisNotes').innerHTML='<p>'+esc(a.method)+'</p>'+a.warnings.map(w=>'<p>· '+esc(w)+'</p>').join('');
  $('inputMessage').textContent='비교 완료 · '+sourceLabel[input.provenance];
  state.school?.setData([{id:input.reference.id,count:a.reference.average},{id:input.target.id,count:a.target.average}]);
}
async function compare() {
  showError('');$('analyzeBtn').disabled=true; const revision=state.revision;
  try { const data=await api('/api/analyze',requestInput());if(revision===state.revision)renderAnalysis(data); }
  catch(e){showError(e.message);$('inputMessage').textContent=e.message;}
  finally{$('analyzeBtn').disabled=false;}
}
function renderRecommendations(result) {
  state.result=result;$('downloadBtn').disabled=false;
  $('recommendation').innerHTML=`<div class="result-summary"><span class="pill">${result.source==='openai'?'OpenAI 생성':'로컬 규칙 기반'} · ${esc(sourceLabel[result.provenance])}</span><p>${esc(result.summary)}</p>${result.warning?'<p class="help">'+esc(result.warning)+'</p>':''}<p class="help">${esc(result.conceptualLens)}</p></div><div class="option-grid">`+result.options.map((o,i)=>`<article class="option-card"><div class="option-header"><span class="option-index">0${i+1}</span><div><h3>${esc(o.name)}</h3><span class="help">검토 시간 ${esc(hours(o.suitableHours))} · 시간표 확인 필요</span></div></div><p>${esc(o.use)}</p><h4>학생이 할 수 있는 행동</h4>${list(o.studentBehaviors)}<h4>이용 패턴과 연결한 이유</h4><div class="option-detail">${esc(o.patternFit)}</div><div class="pros-cons"><div><h4>+ 장점</h4>${list(o.advantages)}</div><div><h4>− 단점</h4>${list(o.disadvantages)}</div></div><h4>필요한 조건과 변경</h4>${list(o.requiredConditions)}<h4>학교에 적합한 이유</h4><div class="option-detail">${esc(o.schoolFit)}</div><details open><summary>중복·소음·혼잡 검토</summary><h4>기존 시설과의 구분</h4><div class="option-detail">${esc(o.facilityDifferentiation)}</div><h4>운영 시 고려할 점</h4><div class="option-detail">${esc(o.noiseAndCongestion)}</div></details></article>`).join('')+'</div>';
}
async function generate() {
  showError('');const revision=state.revision;$('recommendBtn').disabled=true;$('recommendBtn').textContent='5개 선택지를 작성하고 있습니다…';
  try{const result=await api('/api/recommend',requestInput());if(revision!==state.revision)return;renderAnalysis({analysis:result.analysis,input:result.input});renderRecommendations(result);}
  catch(e){if(revision===state.revision){showError(e.message);$('recommendation').textContent=e.message;}}
  finally{$('recommendBtn').disabled=false;$('recommendBtn').textContent='활용 선택지 5개 생성 ↗';}
}
function loadDemo() {
  $('referenceId').value='HONGIK-2-LIBRARY';$('targetId').value='MAIN-4-11';$('provenance').value='demo';
  $('countsInput').value='09:00, 12, 2\n10:00, 18, 1\n11:00, 15, 3\n12:00, 25, 5\n13:00, 22, 4\n14:00, 14, 2\n15:00, 10, 1\n16:00, 8, 2';
  $('observationContext').value='인원수는 기능 확인용 예시 · 시설 목록은 2024 배치도 기준(현재 운영 미확인)';clearResults('초기 인원수는 예시입니다. 실제 데이터를 입력한 뒤 활용안을 검토하세요.');compare();
}
async function saveObservation(count,source) {
  if(state.saving)return;state.saving=true;
  const now=new Date(),spaceId=source==='webcam'?state.cameraSpace:$('captureSpace').value;
  const localD=source==='webcam'?localDate(now):$('captureDate').value,localT=source==='webcam'?localTime(now):$('captureTime').value;
  try{await api('/api/observations',{spaceId,count,source,localDate:localD,localTime:localT});log(`${localD} ${localT} · ${state.spaces.find(s=>s.id===spaceId)?.name} · ${count}명 저장 (${source==='webcam'?'웹캠':'수동'})`);}
  finally{state.saving=false;}
}
async function startCamera() {
  if($('detectionEngine').value==='yolo')return yoloUI.start();
  $('detectionEngine').disabled=true;
  $('cameraBtn').disabled=true;$('captureSpace').disabled=true;state.cameraSpace=$('captureSpace').value;
  try {
    if(!state.camera){const {createPeopleCamera}=await import('./camera.js');state.camera=createPeopleCamera({video:$('video'),canvas:$('overlay'),
      onStatus:text=>{$('cameraMessage').textContent=text;},
      onCount:count=>{state.cameraReady=true;$('personCount').textContent=count;$('captureBtn').disabled=false;$('cameraPlaceholder').hidden=true;
        if($('autoSave').checked&&Date.now()-state.lastAutoSave>=5000&&!state.saving){state.lastAutoSave=Date.now();saveObservation(count,'webcam').catch(e=>{log(e.message,true);$('autoSave').checked=false;});}},
      onFailure:message=>{stopCamera();$('cameraMessage').textContent=message;}});}
    await state.camera.start();$('stopCamera').disabled=false;$('cameraBtn').textContent='탐지 실행 중';
  }catch(e){stopCamera();$('cameraMessage').textContent='카메라 시작 실패: '+e.message;}
}
function stopCamera(){if(yoloUI?.active)return yoloUI.stop();state.camera?.stop();state.cameraReady=false;state.cameraSpace=null;$('detectionEngine').disabled=false;$('cameraBtn').disabled=false;$('cameraBtn').textContent='카메라 시작';$('stopCamera').disabled=true;$('captureBtn').disabled=true;$('captureSpace').disabled=false;$('autoSave').checked=false;$('personCount').textContent='—';$('cameraPlaceholder').hidden=false;}

$('floorTabs').addEventListener('click',e=>{const b=e.target.closest('[data-floor]');if(b)setFloor(b.dataset.floor);});
$('buildingFilter').addEventListener('change',()=>setBuilding($('buildingFilter').value));
$('spaceList').addEventListener('click',e=>{const b=e.target.closest('[data-id]');if(b)selectSpace(b.dataset.id);});
$('dataToggle').addEventListener('change',()=>state.school?.setDataVisible($('dataToggle').checked));
$('resetView').addEventListener('click',()=>state.school?.resetView());
$('useTarget').addEventListener('click',()=>{if(state.selectedId===$('referenceId').value){showError('기준 공간과 다른 공간을 대상으로 선택하세요.');return;}$('targetId').value=state.selectedId;$('countsInput').value='';$('provenance').value='manual';clearResults('대상 공간을 바꿨습니다. 해당 공간의 데이터나 저장 기록을 입력하세요.');});
for(const id of ['referenceId','targetId'])$(id).addEventListener('change',()=>{$('countsInput').value='';$('provenance').value='manual';clearResults('공간을 바꿨습니다. 해당 공간의 데이터를 새로 입력하거나 관측 기록을 불러오세요.');});
for(const id of ['countsInput','existingFacilities','manualProperties','observationContext','provenance'])$(id).addEventListener('input',()=>{if(id==='countsInput'&&$('provenance').value==='observations')$('provenance').value='manual';clearResults();});
$('analyzeBtn').addEventListener('click',compare);$('demoBtn').addEventListener('click',loadDemo);$('recommendBtn').addEventListener('click',generate);
$('downloadBtn').addEventListener('click',()=>{if(!state.result)return;const link=document.createElement('a');const url=URL.createObjectURL(new Blob([JSON.stringify(state.result,null,2)],{type:'application/json'}));link.href=url;link.download='school-space-options-'+localDate()+'.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
$('saveManual').addEventListener('click',async()=>{$('saveManual').disabled=true;try{const value=$('manualCount').value;if(value==='')throw new Error('수동 계수 인원을 입력하세요.');await saveObservation(Number(value),'manual');}catch(e){log(e.message,true);}finally{$('saveManual').disabled=false;}});
$('loadObservations').addEventListener('click',async()=>{
  try{const params=new URLSearchParams({date:$('loadDate').value,referenceId:$('referenceId').value,targetId:$('targetId').value});const result=await api('/api/observations?'+params);
    if(!result.series.length)throw new Error('해당 날짜의 두 공간에 저장된 관측 기록이 없습니다.');
    $('countsInput').value=result.series.map(r=>`${r.time}, ${r.reference??''}, ${r.target??''}`).join('\n');$('provenance').value='observations';$('observationContext').value=result.date+' · '+result.method;
    clearResults();log(result.series.length+'개 시간대 기록을 불러왔습니다.');await compare();
  }catch(e){log(e.message,true);}
});
$('cameraBtn').addEventListener('click',startCamera);$('stopCamera').addEventListener('click',stopCamera);
$('captureBtn').addEventListener('click',async()=>{if($('detectionEngine').value==='yolo')return yoloUI.capture();if(!state.cameraReady)return;try{await saveObservation(state.camera.count,'webcam');}catch(e){log(e.message,true);}});
window.addEventListener('beforeunload',()=>state.camera?.stop());
window.addEventListener('pagehide',()=>state.camera?.stop());

async function boot() {
  for(const id of ['captureDate','loadDate'])$(id).value=localDate();$('captureTime').value=localTime();
  const [spaces,health]=await Promise.all([api('/api/spaces'),api('/api/health')]);state.spaces=spaces;
  for(const id of ['referenceId','targetId','captureSpace'])$(id).innerHTML=spaces.map(s=>`<option value="${esc(s.id)}">${esc(spaceLabel(s))}</option>`).join('');
  $('captureSpace').value='MAIN-4-11';$('existingFacilities').value=EXISTING_FACILITIES.join('\n');$('serverStatus').textContent=health.aiConfigured?'서버 연결 · OpenAI 설정됨':'서버 연결 · 로컬 분석';renderSpaces();window.appReady=true;
  yoloUI=createYoloUI({$,api,log});await yoloUI.restore();
  loadDemo();
  try {const {createSchool}=await import('./school.js');state.school=createSchool($('scene'),spaces,selectSpace);state.school.highlight(state.selectedId);if(state.analysis)renderAnalysis(state.analysis);}
  catch(e){$('scene').innerHTML='<div class="scene-loading">3D 화면을 불러오지 못했습니다.<br>npm.cmd install 후 새로고침하거나 브라우저의 그래픽 가속을 확인하세요.<br>'+esc(e.message)+'</div>';console.error(e);}
}
boot().catch(e=>{window.appReady=true;showError(e.message);$('serverStatus').textContent='서버 연결 실패';});
