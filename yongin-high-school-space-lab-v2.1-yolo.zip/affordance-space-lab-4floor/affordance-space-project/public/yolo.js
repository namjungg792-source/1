export function createYoloUI({ $, api, log }) {
  let active=false,timer=null,lastSaved=0,disposed=false;
  const busyFields=['detectionEngine','captureSpace','cameraIndex','confidenceThreshold'];
  function lock(value) {for(const id of busyFields)$(id).disabled=value;$('cameraBtn').disabled=value;}
  function describeEngine(){
    const yolo=$('detectionEngine').value==='yolo';$('yoloSettings').hidden=!yolo;
    $('cameraPlaceholder').hidden=false;
    $('cameraPlaceholder').innerHTML=yolo?'<span>YOLOv8n</span><b>영상은 별도 People Counter 창에 표시됩니다</b><small>이 화면에는 현재 인원과 저장 상태가 표시됩니다.</small>':'<span>◎</span>카메라로 재실 인원을 관찰하세요';
    $('cameraMessage').textContent=yolo?'처음 사용하면 SETUP_YOLO.cmd를 실행하세요. 시작 후 별도 영상 창에서 q로 종료할 수 있습니다.':'브라우저 카메라 권한을 허용하세요. MediaPipe 모델을 사용합니다.';
  }
  function render(s) {
    active=s.active;lock(active);$('stopCamera').disabled=!active||s.phase==='stopping';$('captureBtn').disabled=!s.canCapture;
    $('personCount').textContent=s.count??'—';$('cameraBtn').textContent=active?(s.phase==='running'?'YOLO 탐지 실행 중':'YOLO 준비 / 종료 중…'):'카메라 시작';
    $('cameraMessage').textContent=s.saveError?'저장 실패: '+s.saveError:s.message;
    $('autoSave').checked=s.autoSave;
    if(active){$('detectionEngine').value='yolo';$('yoloSettings').hidden=false;$('captureSpace').value=s.spaceId;$('cameraIndex').value=s.cameraIndex;$('confidenceThreshold').value=s.confidence;}
    if(s.savedCount>lastSaved)log('YOLO · '+s.savedCount+'회 저장 완료 · 마지막 저장 '+new Date(s.lastSavedAt).toLocaleTimeString());
    lastSaved=s.savedCount;
    if(!active){clearTimeout(timer);timer=null;}
  }
  function schedule(){
    clearTimeout(timer);if(!active||disposed)return;
    timer=setTimeout(async()=>{
      try{render(await api('/api/yolo/heartbeat',{}));}
      catch(e){$('personCount').textContent='—';$('captureBtn').disabled=true;$('cameraMessage').textContent='YOLO 서버 연결을 확인하세요: '+e.message;}
      schedule();
    },1000);
  }
  async function start(){
    active=true;lock(true);$('stopCamera').disabled=false;$('cameraMessage').textContent='Python YOLO를 실행하고 있습니다…';lastSaved=0;
    try{
      const s=await api('/api/yolo/start',{spaceId:$('captureSpace').value,cameraIndex:Number($('cameraIndex').value),confidence:Number($('confidenceThreshold').value),autoSave:$('autoSave').checked});
      render(s);schedule();
    }catch(e){active=false;lock(false);$('stopCamera').disabled=true;$('cameraBtn').textContent='카메라 시작';$('cameraMessage').textContent=e.message;}
  }
  async function stop(){
    try{render(await api('/api/yolo/stop',{}));schedule();}
    catch(e){$('cameraMessage').textContent='중지 요청 실패: '+e.message;}
  }
  async function capture(){
    $('captureBtn').disabled=true;
    try{const result=await api('/api/yolo/capture',{});render(result.status);}
    catch(e){log(e.message,true);}
  }
  async function setAutoSave(){
    if(!active||$('detectionEngine').value!=='yolo')return;
    try{render(await api('/api/yolo/auto-save',{enabled:$('autoSave').checked}));}
    catch(e){$('autoSave').checked=false;log(e.message,true);}
  }
  async function restore(){
    describeEngine();
    try{const s=await api('/api/yolo/status');if(s.active){render(s);schedule();}}
    catch(e){$('cameraMessage').textContent='YOLO 연동을 사용하려면 새 버전으로 서버를 재시작하세요. '+e.message;}
  }
  function leave(){
    disposed=true;clearTimeout(timer);
    if(active)navigator.sendBeacon('/api/yolo/stop',new Blob(['{}'],{type:'application/json'}));
  }
  $('detectionEngine').addEventListener('change',describeEngine);
  $('autoSave').addEventListener('change',setAutoSave);
  window.addEventListener('pagehide',leave);
  return {start,stop,capture,restore,describeEngine,get active(){return active;}};
}
