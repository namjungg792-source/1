import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { CAMPUS as C, layoutSpaces, worldPosition } from './school-config.js';

export function createSchool(container, spaces, onSelect) {
  const scene=new THREE.Scene();scene.background=new THREE.Color(0xffffff);
  const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.outputColorSpace=THREE.SRGBColorSpace;
  renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;
  renderer.domElement.setAttribute('aria-label','2024 용인고등학교 배치도 기반 3D 캠퍼스. 실제 치수·외관은 미확인입니다.');container.replaceChildren(renderer.domElement);
  const camera=new THREE.PerspectiveCamera(38,1,.1,600);
  const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.minDistance=15;controls.maxDistance=260;controls.maxPolarAngle=Math.PI/2.04;
  scene.add(new THREE.HemisphereLight(0xffffff,0xd1d8c9,2.5));
  const sun=new THREE.DirectionalLight(0xfff4df,2.6);sun.position.set(-45,90,50);sun.castShadow=true;
  Object.assign(sun.shadow.camera,{left:-85,right:85,top:85,bottom:-85,near:1,far:230});sun.shadow.mapSize.set(2048,2048);sun.shadow.normalBias=.04;sun.shadow.bias=-.0001;scene.add(sun);
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(400,400),new THREE.ShadowMaterial({color:0x55614f,opacity:.14}));ground.rotation.x=-Math.PI/2;ground.position.y=-.25;ground.receiveShadow=true;scene.add(ground);
  const materials=Object.fromEntries(Object.entries(C.colors).map(([key,color])=>[key,new THREE.MeshStandardMaterial({color,roughness:key==='glass'?.25:.9,metalness:key==='glass'?.12:0})]));
  const layout=layoutSpaces(spaces),buildings=new Map(),roomMeshes=new Map(),floorParts=[],roofParts=[],buildingLabels=[],connections=[];
  let selectedId='MAIN-4-11',activeFloor='all',activeBuilding='all',dataVisible=false,dataRows=[],selection=null,frame;
  function box(parent,x,y,z,w,h,d,material=materials.plaster){
    const obj=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);obj.position.set(x,y,z);obj.castShadow=true;obj.receiveShadow=true;parent.add(obj);return obj;
  }
  function line(parent,points,color=C.colors.metal,depthTest=true){
    const obj=new THREE.Line(new THREE.BufferGeometry().setFromPoints(points.map(p=>new THREE.Vector3(...p))),new THREE.LineBasicMaterial({color,depthTest}));parent.add(obj);return obj;
  }
  function tag(text,w=8,h=1.1,ink='#345746'){
    const cv=document.createElement('canvas');cv.width=640;cv.height=100;const ctx=cv.getContext('2d');
    ctx.fillStyle='#f9fbf5';ctx.fillRect(0,0,640,100);ctx.fillStyle=ink;ctx.font='600 36px "Malgun Gothic",sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,320,52,610);
    const texture=new THREE.CanvasTexture(cv);texture.colorSpace=THREE.SRGBColorSpace;const obj=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,depthTest:false}));obj.scale.set(w,h,1);obj.renderOrder=8;return obj;
  }
  function windowBay(parent,x,y,z,w,h=1.7,side=false){
    const group=new THREE.Group();group.position.set(x,y,z);if(side)group.rotation.y=Math.PI/2;
    box(group,0,0,0,w,h,.12,materials.glass);
    for(const dy of [-h/2,.23,h/2])box(group,0,dy,.08,w+.1,.055,.15,materials.frame);
    const n=Math.max(2,Math.round(w/1.4));for(let i=0;i<=n;i++)box(group,-w/2+w*i/n,0,.1,.055,h+.1,.13,materials.frame);
    box(group,0,-h/2-.1,.1,w+.25,.12,.32,materials.slab);parent.add(group);
  }
  function rail(parent,x1,z1,x2,z2,y){
    line(parent,[[x1,y+.85,z1],[x2,y+.85,z2]]);line(parent,[[x1,y+.38,z1],[x2,y+.38,z2]]);
    const n=Math.max(1,Math.ceil(Math.hypot(x2-x1,z2-z1)/1.8));
    for(let i=0;i<=n;i++){const x=x1+(x2-x1)*i/n,z=z1+(z2-z1)*i/n;line(parent,[[x,y,z],[x,y+.85,z]]);}
  }
  const site=new THREE.Group();scene.add(site);
  box(site,0,-.17,7,88,.13,94,materials.slab);
  // White forecourt, perimeter and gates follow the arrangement in the supplied diagram.
  box(site,0,-.08,23,46,.08,43,materials.plaster);
  line(site,[[-45,0,51],[45,0,51],[45,0,-8],[30,0,-26],[8,0,-28],[-7,0,-48],[-45,0,-48],[-45,0,51]],0xa4b29b);
  for(const [text,x,z]of [['정문',44,48],['후문',-30,51],['조회대',0,1],['분리수거장',-34,-22]]){
    const label=tag(text,6,1.1);label.position.set(x,.8,z);site.add(label);
  }
  box(site,0,.4,1,6,.8,3,materials.brick);
  box(site,-34,.4,-22,5,.8,2,materials.hall);
  for(const [x,z]of [[-42,-15],[-42,7],[-42,28],[42,6],[42,27],[42,44],[-17,47],[4,47],[20,47],[-44,-37]]){
    const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.17,.23,1.8,7),materials.brick);trunk.position.set(x,.8,z);site.add(trunk);
    const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(1.35,1),new THREE.MeshStandardMaterial({color:0x9daa89,roughness:1}));crown.position.set(x,2,z);crown.scale.y=1.35;crown.castShadow=true;site.add(crown);
  }
  for(const x of [-14,-5,5,14]){box(site,x,.45,14,3,.12,.65,materials.brick);for(const dx of [-1,1])box(site,x+dx,.22,14,.1,.42,.55,materials.metal);}

  for(const b of C.buildings){
    const root=new THREE.Group();root.position.set(b.x,0,b.z);root.rotation.y=b.rotation;scene.add(root);buildings.set(b.id,{root,config:b});
    const fh=b.floorHeight||C.floorHeight;
    for(let f=1;f<=b.floors;f++){
      const group=new THREE.Group();group.position.y=(f-1)*fh;root.add(group);
      const facade=new THREE.Group(),interior=new THREE.Group(),labels=new THREE.Group(),flow=new THREE.Group();group.add(facade,interior,labels,flow);
      floorParts.push({building:b.id,floor:f,group,facade,interior,labels,flow});
      box(group,0,.05,0,b.width,.22,b.depth,materials.slab);
      if(b.rearBlock)box(group,0,.05,-b.depth/2-2,13,.22,4,materials.slab);
      const rooms=layout.filter(r=>r.building===b.id&&r.floor===f);
      for(const r of rooms){
        const tile=box(group,r.x,.22,r.z,r.w-.08,.12,r.d-.08,(r.row==='hall'?materials.hall:materials.floor).clone());tile.userData.spaceId=r.id;roomMeshes.set(r.id,tile);
        const pick=box(group,r.x,fh/2,r.z,r.w-.08,fh-.2,r.d-.08,new THREE.MeshBasicMaterial({visible:false}));pick.userData.spaceId=r.id;tile.userData.pick=pick;
        if(r.row==='rooms'||r.row==='rear'){
          const outer=r.z+r.d/2,roofRoom=r.type==='옥상';
          for(const x of [r.x-r.w/2+.055,r.x+r.w/2-.055])box(interior,x,.66,r.z,.11,.8,r.d,materials.plaster);
          box(interior,r.x,.66,r.z-r.d/2,Math.max(.2,r.w-1.1),.8,.11,materials.plaster);
          if(roofRoom){rail(group,r.x-r.w/2,outer,r.x+r.w/2,outer,.3);}
          else{
            const sill=b.id==='GYM'?2.4:1.15,winY=b.id==='GYM'?4.5:1.98,winH=b.id==='GYM'?2.2:1.6;
            box(facade,r.x,sill/2+.22,outer,r.w,sill,.22,materials.plaster);
            const topStart=winY+winH/2;
            box(facade,r.x,(topStart+fh)/2,outer,r.w,fh-topStart,.24,materials.plaster);
            for(const dx of [-r.w/2+.12,r.w/2-.12])box(facade,r.x+dx,fh/2,outer,.24,fh,.32,materials.brick);
            const n=Math.max(1,Math.round(r.w/7));for(let k=0;k<n;k++)windowBay(facade,r.x-r.w/2+(k+.5)*r.w/n,winY,outer+.1,Math.max(.6,r.w/n-.7),winH);
          }
          if(r.type==='일반교실'){
            for(let k=0;k<2;k++)for(let j=0;j<2;j++){const x=r.x+(j-.5)*Math.min(2.1,r.w/2),z=r.z+(k-.5)*2.2;box(interior,x,.84,z,.85,.08,.6,materials.brick);box(interior,x,.5,z,.065,.6,.065,materials.metal);box(interior,x,.45,z+.65,.45,.07,.4,materials.frame);}
            box(interior,r.x,1.05,r.z-r.d/2+.13,Math.min(2.5,r.w*.7),1.15,.1,materials.metal);
          }
        }else if(r.row==='stair'){
          box(facade,r.x,1.1,b.depth/2,r.w,2,.24,materials.brick);
          windowBay(facade,r.x,2.45,b.depth/2+.12,Math.max(.8,r.w-.4),1.5);
          for(let k=0;k<12;k++)box(interior,r.x,.3+k*.14,r.z-r.d/2+.8+k*.35,Math.max(1,r.w-.4),.12,.4,materials.slab);
          rail(interior,r.x-r.w/2+.1,r.z-2,r.x-r.w/2+.1,r.z+2,.4);
        }
        if(!['hall','stair'].includes(r.row)){
          const label=tag(r.name,Math.min(r.w*.95,8),.85);label.position.set(r.x,1.65,r.z);labels.add(label);
        }
      }
      // Rear corridor glazing and flat floor bands form the characteristic school elevation.
      if(b.corridor){
        box(facade,0,.72,-b.depth/2,b.width,1.3,.22,materials.plaster);
        box(facade,0,fh-.25,-b.depth/2,b.width,.5,.22,materials.plaster);
        const n=Math.max(1,Math.round(b.width/6.5));for(let k=0;k<n;k++)windowBay(facade,-b.width/2+(k+.5)*b.width/n,2.03,-b.depth/2-.12,b.width/n-.8,1.4);
      }else box(facade,0,fh/2,-b.depth/2,b.width,fh,.2,materials.plaster);
      for(const x of [-b.width/2,b.width/2]){
        box(facade,x,fh/2,0,.23,fh,b.depth,materials.brick);
        if(b.depth>7)windowBay(facade,x,Math.min(2.1,fh/2),0,b.depth*.55,1.55,true);
      }
      for(const z of [-b.depth/2,b.depth/2])box(facade,0,fh-.1,z,b.width+.3,.2,.4,materials.frame);
      if(b.rearBlock){
        box(facade,0,fh/2,-b.depth/2-4,13,fh,.2,materials.plaster);
        for(const x of [-6.5,6.5])box(facade,x,fh/2,-b.depth/2-2,.2,fh,4,materials.plaster);
        for(const x of [-4.7,0,4.7])windowBay(facade,x,1.95,-b.depth/2-4.13,2.8,1.35);
      }
      if(f===1 && b.corridor){
        const entrance=b.id==='MAIN'?rooms.find(r=>r.name==='중앙현관'):{x:-b.width/2+1.5};
        const x=entrance?.x||0;
        box(facade,x,1.3,b.depth/2+.16,3,2.4,.15,materials.glass);
        for(const dx of [-1.5,0,1.5])box(facade,x+dx,1.4,b.depth/2+.3,.1,2.7,.12,materials.frame);
        box(facade,x,2.88,b.depth/2+1.2,5,.18,2.8,materials.frame);
        for(const dx of [-2.25,2.25])box(facade,x+dx,1.35,b.depth/2+2.3,.13,2.7,.13,materials.metal);
        for(let k=0;k<3;k++)box(facade,x,.06+k*.09,b.depth/2+1.7-k*.3,5.4-k*.25,.12,2.1-k*.5,materials.slab);
      }
    }
    const roof=new THREE.Group();roof.position.y=b.floors*fh;root.add(roof);roofParts.push({building:b.id,roof});
    box(roof,0,0,0,b.width+.35,.2,b.depth+.35,materials.roof);
    for(const z of [-b.depth/2,b.depth/2])box(roof,0,.33,z,b.width,.65,.21,materials.plaster);
    for(const x of [-b.width/2,b.width/2])box(roof,x,.33,0,.21,.65,b.depth,materials.plaster);
    if(b.corridor){rail(roof,-b.width/2,b.depth/2,b.width/2,b.depth/2,.3);box(roof,-b.width/2+2,.6,0,3,1.2,4,materials.plaster);}
    if(b.rearBlock){box(roof,0,0,-b.depth/2-2,13,.2,4,materials.roof);box(roof,0,.32,-b.depth/2-4,13,.65,.2,materials.plaster);}
    const title=tag(b.name+(b.floors>1?' · '+b.floors+'F':''),b.id==='MAIN'?12:10,1.5);title.position.set(b.x,b.floors*fh+2.8,b.z);scene.add(title);buildingLabels.push({building:b.id,title});
  }
  // Connection locations/levels follow the diagram; widths and lengths remain illustrative.
  for(const bridge of [{x:-30,z:1.1,w:3,d:7.2,floors:[1,2],name:'서측 연결통로(1층 통제 표기)'},{x:28,z:3,w:3,d:10.5,floors:[1,3],name:'홍익관 연결통로'}]){
    for(const f of bridge.floors){
      const g=new THREE.Group();g.position.y=(f-1)*C.floorHeight;scene.add(g);connections.push({floor:f,group:g});
      box(g,bridge.x,.16,bridge.z,bridge.w,.18,bridge.d,materials.slab);
      rail(g,bridge.x-bridge.w/2,bridge.z-bridge.d/2,bridge.x-bridge.w/2,bridge.z+bridge.d/2,.25);
      rail(g,bridge.x+bridge.w/2,bridge.z-bridge.d/2,bridge.x+bridge.w/2,bridge.z+bridge.d/2,.25);
    }
  }
  const schoolSign=tag('용인고등학교',13,1.75);schoolSign.position.set(0,17,-.8);scene.add(schoolSign);
  function matches(room){return (activeBuilding==='all'||room.building===activeBuilding)&&(activeFloor==='all'||room.floor===Number(activeFloor));}
  function highlight(id){
    selectedId=id;
    for(const [key,mesh]of roomMeshes){const r=layout.find(r=>r.id===key);mesh.material.color.set(key===id?C.colors.selected:r.row==='hall'?C.colors.hall:C.colors.floor);}
    if(selection){scene.remove(selection);selection.geometry.dispose();selection.material.dispose();}
    const r=layout.find(r=>r.id===id);if(!r)return;
    const b=C.buildings.find(b=>b.id===r.building),pos=worldPosition(r),fh=b.floorHeight||C.floorHeight;
    const g=new THREE.BoxGeometry(r.w-.12,activeFloor==='all'?fh-.3:.22,r.d-.12);
    selection=new THREE.LineSegments(new THREE.EdgesGeometry(g),new THREE.LineBasicMaterial({color:0x3e6836,depthTest:false,transparent:true,opacity:.85}));g.dispose();
    selection.position.set(pos.x,(r.floor-1)*fh+(activeFloor==='all'?fh/2+.15:.42),pos.z);selection.rotation.y=b.rotation;selection.visible=matches(r);scene.add(selection);
  }
  function setData(rows){dataRows=rows;updateFlows();}
  function updateFlows(){
    for(const p of floorParts){
      for(const o of [...p.flow.children]){p.flow.remove(o);o.geometry.dispose();o.material.dispose();}
      p.flow.visible=dataVisible;
      const b=C.buildings.find(b=>b.id===p.building);
      for(const d of dataRows){
        const r=layout.find(r=>r.id===d.id&&r.floor===p.floor&&r.building===p.building);
        if(!r||!Number.isFinite(d.count)||d.count<=0)continue;
        const y=(b.floorHeight||C.floorHeight)-.03,hallZ=-(b.depth-b.corridor)/2;
        const l=line(p.flow,[[r.x,y,r.z],[r.x,y,hallZ],[-b.width/2+1.5,y,hallZ]],0x000000,false);l.renderOrder=6;
      }
    }
  }
  function resetView(){
    const b=C.buildings.find(b=>b.id===activeBuilding),floorY=activeFloor==='all'?5:(Number(activeFloor)-1)*C.floorHeight;
    if(b){
      controls.target.set(b.x,floorY,b.z);const size=Math.max(b.width,b.depth);
      camera.position.set(b.x+size*.62,floorY+size*(activeFloor==='all'?.52:1.05),b.z+size*.8);
    }else{
      controls.target.set(0,floorY,0);camera.position.set(96,activeFloor==='all'?85:135,123);
    }
    if(container.clientWidth/container.clientHeight<1.1)camera.position.sub(controls.target).multiplyScalar(1.3).add(controls.target);
    controls.update();
  }
  function visibility(){
    for(const [id,b]of buildings)b.root.visible=activeBuilding==='all'||activeBuilding===id;
    for(const p of floorParts){p.group.visible=activeFloor==='all'||p.floor===Number(activeFloor);p.facade.visible=activeFloor==='all';p.interior.visible=activeFloor!=='all';p.labels.visible=activeFloor!=='all'&&activeBuilding!=='all';}
    for(const p of roofParts)p.roof.visible=activeFloor==='all';
    for(const p of buildingLabels){p.title.visible=activeBuilding==='all'||activeBuilding===p.building;const b=C.buildings.find(b=>b.id===p.building);p.title.position.y=activeFloor==='all'?b.floors*(b.floorHeight||C.floorHeight)+2.8:(Number(activeFloor)-1)*C.floorHeight+2;p.title.visible=p.title.visible&&(activeFloor==='all'||Number(activeFloor)<=b.floors);}
    for(const p of connections)p.group.visible=activeBuilding==='all'&&(activeFloor==='all'||p.floor===Number(activeFloor));
    site.visible=activeBuilding==='all'&&activeFloor==='all';schoolSign.visible=activeFloor==='all'&&(activeBuilding==='MAIN'||activeBuilding==='all');highlight(selectedId);resetView();
  }
  const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();let down;
  renderer.domElement.addEventListener('pointerdown',e=>down=[e.clientX,e.clientY]);
  renderer.domElement.addEventListener('pointerup',e=>{
    if(!down||Math.hypot(e.clientX-down[0],e.clientY-down[1])>5)return;
    const rect=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1);raycaster.setFromCamera(pointer,camera);
    const candidates=layout.filter(matches).map(r=>{const tile=roomMeshes.get(r.id);return activeFloor==='all'?tile.userData.pick:tile;});
    const hit=raycaster.intersectObjects(candidates,false)[0];if(hit){highlight(hit.object.userData.spaceId);onSelect(hit.object.userData.spaceId);}
  });
  renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();cancelAnimationFrame(frame);const p=document.createElement('p');p.className='error';p.textContent='3D 그래픽 연결이 끊겼습니다. 새로고침하면 다시 불러옵니다.';container.append(p);});
  const resize=new ResizeObserver(()=>{const w=container.clientWidth,h=container.clientHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h);});resize.observe(container);
  function animate(){frame=requestAnimationFrame(animate);controls.update();renderer.render(scene,camera);}
  visibility();updateFlows();animate();
  return {highlight,resetView,setData,setFloor(value){activeFloor=String(value);visibility();},setBuilding(value){activeBuilding=value;visibility();},setDataVisible(value){dataVisible=value;updateFlows();}};
}
