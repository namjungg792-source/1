// Layout transcribed from the user-supplied 2024 plan; dimensions are adjustable
// illustration assumptions, NOT measured school geometry and NOT AI analysis data.
export const CAMPUS = {
  schoolName: '용인고등학교', sourceYear: 2024, floorHeight: 3.6,
  buildings: [
    { id:'MAIN', name:'본관', floors:4, x:0, z:-7, rotation:0, width:76, depth:11, corridor:3, stairWidth:2.4, rearBlock:true },
    { id:'ANNEX', name:'서측 교실동', floors:5, x:-30, z:23, rotation:-Math.PI/2, width:37, depth:11, corridor:3, stairWidth:2.8 },
    { id:'HONGIK', name:'홍익관', floors:4, x:28, z:24, rotation:-Math.PI/2, width:31, depth:17, corridor:3, stairWidth:2.8 },
    { id:'GYM', name:'체육관', floors:1, x:-27, z:-37, rotation:0, width:24, depth:16, corridor:0, stairWidth:0, floorHeight:7.5 },
    { id:'STORE', name:'창고', floors:1, x:7, z:-35, rotation:0, width:6, depth:4, corridor:0, stairWidth:0, floorHeight:3 }
  ],
  colors: { plaster:0xebe7dc, brick:0xa58c7c, slab:0xd9dbd1, glass:0x709597, frame:0xe7e8df, roof:0xc5cec3, floor:0xe6e1d1, hall:0xcdd9c6, selected:0x91b477, metal:0x53685e },
  // Example override: 'MAIN-4-11': { x:32, z:1.5, w:6, d:8 }.
  // Local coordinates are relative to the building centre; never interpreted as measured inputs.
  roomOverrides: {}
};
export const EXISTING_FACILITIES = [
  '일반교실','도서관(홍익관 2층)','열람실','자기주도학습실','진로활동실','위클래스',
  '학년별 상담실','홈베이스','프로젝트 활동실1·2·3','학생자치회실',
  '음악실','미술실','컴퓨터실','가정과학실','융합과학실 I·II·III',
  '체육관','학생식당','교직원식당','조리실','보건실','방송실','전환1·2·3실'
];
export function layoutSpaces(spaces) {
  return spaces.map(s=>{
    const b=CAMPUS.buildings.find(b=>b.id===s.building);
    const siblings=spaces.filter(p=>p.building===s.building&&p.floor===s.floor&&p.row==='rooms').sort((a,b)=>a.order-b.order);
    const sum=siblings.reduce((sum,r)=>sum+r.units,0),nStairs=b.id==='MAIN'?2:b.stairWidth?1:0;
    const usable=b.width-nStairs*b.stairWidth, roomDepth=b.depth-b.corridor;
    const widths=siblings.map(r=>usable*r.units/sum);
    let rect;
    if(s.row==='rooms'){
      const i=siblings.findIndex(r=>r.id===s.id);
      let x=-b.width/2+widths.slice(0,i).reduce((a,b)=>a+b,0)+widths[i]/2;
      if(b.id==='MAIN'){if(i>=1)x+=b.stairWidth;if(i===siblings.length-1)x+=b.stairWidth;}
      else if(nStairs)x+=b.stairWidth;
      rect={x,z:b.corridor/2,w:widths[i],d:roomDepth};
    } else if(s.row==='hall') rect={x:0,z:-roomDepth/2,w:b.width,d:b.corridor};
    else if(s.row==='stair'){
      const x=b.id==='MAIN'?(s.order<0?-b.width/2+widths[0]+b.stairWidth/2:b.width/2-widths.at(-1)-b.stairWidth/2):-b.width/2+b.stairWidth/2;
      rect={x,z:b.corridor/2,w:b.stairWidth,d:roomDepth};
    } else rect={x:0,z:-b.depth/2-2,w:8,d:4};
    return {...s,...rect,...CAMPUS.roomOverrides[s.id]};
  });
}
export function worldPosition(room) {
  const b=CAMPUS.buildings.find(b=>b.id===room.building),c=Math.cos(b.rotation),s=Math.sin(b.rotation);
  return {x:b.x+room.x*c+room.z*s,z:b.z-room.x*s+room.z*c};
}
