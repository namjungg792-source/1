# 검증 기록

검증일: 2026-09-30 · Windows · Node v24.19.0 · npm 11.19.0

- `npm.cmd install`: 성공, package-lock.json 포함.
- `npm.cmd start`: localhost:3000 정상 기동.
- `npm.cmd run check`: server/app/school/camera 문법 검사 통과.
- `npm.cmd test`: 13개 통과. 통계·동률·결측·0명·입력 거부·시간 정렬·공통 시간 비교·물리 점수 미사용·5개 추천 구조·기존 시설 중복 조건·Responses 파싱·AI 오류 대체·저장 직렬화·정적 모듈/MIME·경로 제한·공간 구성 검사.
- 실제 브라우저: 초기 화면·Three.js 모델 로딩, 오류 로그 없음. 본관 4층 공간 선택(진로활동실), 서측 교실동 5층 7개 선택 공간, 데이터 선 토글, 추천 카드 5개, JSON 저장 버튼 활성화 확인.
- 390px 화면: 가로 넘침 없음. 음수 인원 거부, 입력 변경 시 이전 추천·다운로드 비활성화 확인.
- 로컬 MediaPipe JS/WASM + 동봉 EfficientDet Lite0 모델: 빈 320×240 프레임 추론 성공(검출 0명). 실제 카메라 권한이나 사용자의 영상을 사용하지 않음.
- 실제 OpenAI API 호출은 API 키가 없어 미실행. 요청 JSON/응답 파싱/실패 대체는 모의 응답으로 검증.
- 실제 카메라 하드웨어 계수와 현장 정확도는 미검증. 직접 카메라 시작 후 확인 필요.

학교의 실제 치수·입면·현재 시설 운영은 검증 범위가 아닙니다. 2024 배치도에서 확인되는 층별 명칭/상대 배치를 반영하고 나머지는 가정값으로 분리했습니다.

## 2.1 / YOLO 추가 검증 (2026-10-01)

- 격리된 Python 3.12.14 환경에서 requirements-yolo.txt 설치 성공. 긴 프로젝트 경로의 Windows 패키지 설치 실패를 재현하고, 배포 설치 스크립트는 짧은 전용 가상환경 경로를 사용하도록 수정.
- 실제 설치 환경: Ultralytics 8.3.228, OpenCV 4.11.0, PyTorch 2.14.1, torchvision 0.29.1, NumPy 2.5.3. 참고용 전체 목록: requirements-yolo-validated.txt.
- people_counter.py --check 성공.
- 공식 Ultralytics assets의 yolov8n.pt로 people_counter.py --self-test 성공: 빈 320×320 프레임, 사람 클래스만 추론, 0명, cameraOpened=false. 모델을 ZIP에 포함.
- npm.cmd install, npm.cmd run check 성공.
- npm.cmd test: 기존 13개 + YOLO 8개 = **21개 통과**. 입력 검증, 고정 실행 인수, 첫 프레임 전/오래된 결과 저장 차단, 실제 0명 구분, 자동 저장 선택·간격, 중복 저장 방지, 저장 오류 복구, 종료·실행 취소·연결 끊김, HTTP 저장→기존 시간별 평균 연결 검증. 테스트 저장소는 임시 폴더이며 실제 관측에 섞지 않음.
- Python unittest **5개 통과**: person 클래스·confidence 전달, 상자 출력, q 종료·해제, boxes=None, 프레임 실패 시 거짓 0명 미기록, 잘못된 인수 거부.
- npm.cmd start로 서버 시작 성공. 기존 3000/3001 서버가 사용 중이어서 UI 검증은 별도의 임시 포트를 사용. 기본 포트 3000 설정은 유지.
- 실제 브라우저: Three.js 정상 로딩, YOLO/MediaPipe 전환, 기본 1/.5 표시, 웹캠 번호 -1 거부, 탐지 전 저장 비활성화, JS 오류 없음.
- 실제 웹캠은 열지 않았음. 웹 UI→실제 카메라 영상 창 및 현장 인원 정확도는 사용자 하드웨어에서 확인 필요. 실제 AI API 호출은 기존처럼 미검증.
