# Third-party components and sources

- Three.js 0.180.0 — MIT — https://github.com/mrdoob/three
- MediaPipe Tasks Vision 0.10.22-rc.20250304 — Apache-2.0 — https://github.com/google-ai-edge/mediapipe
- AJV 8.17.1 — MIT — https://github.com/ajv-validator/ajv
- EfficientDet Lite0 float16 model: official MediaPipe model asset, version 1.
  Source: https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/float16/1/efficientdet_lite0.tflite
  Official task/model documentation: https://developers.google.com/edge/mediapipe/solutions/vision/object_detector
- OpenAI Structured Outputs implementation reference: https://developers.openai.com/api/docs/guides/structured-outputs
- MediaPipe web implementation reference: https://developers.google.com/edge/mediapipe/solutions/vision/object_detector/web_js
- School plan: user-supplied 2024 Yongin High School facilities diagram, included only as the reference for this requested project.

npm package license metadata is retained in package-lock.json and in installed packages. The model and plan are included as data assets; neither is used as evidence of measured occupancy.

YOLO integration (v2.1):
- Ultralytics 8.3.228 — AGPL-3.0 — https://github.com/ultralytics/ultralytics
  Package license text is included at licenses/ULTRALYTICS-LICENSE.txt.
- yolov8n.pt — official Ultralytics pretrained asset, distributed under the Ultralytics model terms.
  Source: https://github.com/ultralytics/assets/releases/download/v8.3.0/yolov8n.pt
- OpenCV Python 4.11.0.86 — package license notices: https://github.com/opencv/opencv-python
- PyTorch and torchvision: https://github.com/pytorch/pytorch and https://github.com/pytorch/vision
- Implementation references: https://docs.ultralytics.com/modes/predict/ and https://docs.opencv.org/4.x/dd/d43/tutorial_py_video_display.html
Python dependencies are installed separately; their own license notices remain in the environment.
